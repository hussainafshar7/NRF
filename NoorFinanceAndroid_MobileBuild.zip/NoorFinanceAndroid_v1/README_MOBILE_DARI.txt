Noor Finance - Mobile Build

این پروژه برای باز کردن در AndroidIDE روی موبایل آماده شده است.

مراحل:
1) فایل ZIP را استخراج کنید.
2) پوشه NoorFinanceAndroid_v1 را در AndroidIDE باز کنید.
3) اجازه دهید Gradle و Android SDK مورد نیاز آماده شوند.
4) از منوی Build گزینه Assemble/Build APK را اجرا کنید.
5) APK در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نکته: این پروژه در این محیط به APK کامپایل نشده است؛ فایل خروجی واقعی باید توسط AndroidIDE یا یک محیط Android SDK ساخته شود.
